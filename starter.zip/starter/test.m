patches = sampleIMAGES;
visibleSize = 64;
hiddenSize = 25;
sparsityParam = 0.01;
beta =3;
lambda = 0.0001;
m = 100;
theta = initializeParameters(hiddenSize, visibleSize);
W1 = reshape(theta(1:hiddenSize*visibleSize), hiddenSize, visibleSize);
W2 = reshape(theta(hiddenSize*visibleSize+1:2*hiddenSize*visibleSize), visibleSize, hiddenSize);
b1 = theta(2*hiddenSize*visibleSize+1:2*hiddenSize*visibleSize+hiddenSize);
b2 = theta(2*hiddenSize*visibleSize+hiddenSize+1:end);
W1grad = zeros(size(W1)); 
W2grad = zeros(size(W2));
b1grad = zeros(size(b1)); 
b2grad = zeros(size(b2));
%chu shi can shu
z2 = W1 * patches + b1;
a2 = sigmoid(z2);
z3 = W2 * a2 + b2;
a3 = sigmoid(z3);
hbw = a3;
rho = sum( a2, 2 ) / m;
%
delta3 = -(patches - a3).*(a3.*(1-a3));
delta2 = ((W2.' * delta3) + (beta * (-sparsityParam./rho + (1-sparsityParam)./(1-rho)))).* (a2.*(1-a2));
%
W2J = delta3 * a2.';
W1J = delta2 * patches.';
%
W1grad = W1grad + W1J;
W2grad = W2grad + W2J;
W1grad = 1/m * W1grad + lambda * W1; %need to fix 10 to 10000 later
W2grad = 1/m * W2grad + lambda * W2;
%
b2J = delta3 * ones(m,1);
b1J = delta2 * ones(m,1);
b1grad = b1grad + b1J;
b2grad = b2grad + b2J;
b1grad = 1/m * b1grad;
b2grad = 1/m * b2grad;
%
grad_result = [W1grad(:) ; W2grad(:) ; b1grad(:) ; b2grad(:)];
%


dist = 0;
for i = 1:m
    dist1 = norm(hbw(:,i) - patches(:,i))^2;
    dist = dist +dist1;
end
dist = dist/m/2; % 10 to 10000

distnew = 1 / m / 2 * norm( hbw - patches ) .^ 2;
%


W1new = W1.^2;
W2new = W2.^2;

Wsum = sum(W1new(:)) + sum(W2new(:));

KL = 0;
for j = 1:hiddenSize
    rho_j = sum(a2(j,:))/m;
    KL = KL + sparsityParam * log(sparsityParam/rho_j) + ...
        (1 - sparsityParam) * log((1 - sparsityParam) / (1 - rho_j));
end

cost = dist + lambda/2*Wsum + beta * KL;

costnew = 1 / m / 2 * norm( hbw - patches ) .^ 2 + lambda * ( sum(W1new(:)) + sum(W2new(:)) ) + ...
	   beta * compKL( sparsityParam, rho );



function sigm = sigmoid(x)
  
    sigm = 1 ./ (1 + exp(-x));
end
function kl = compKL(sparsityParam, rho)

    kl = sum(sparsityParam.*log(sparsityParam./rho) +...
        (1-sparsityParam).*log((1-sparsityParam)./(1-rho)));

end
